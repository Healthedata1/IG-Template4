package http://www.fhir.org/guides/test4/ImplementationGuide/healthedatainc.ig-template4;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class Templatebasic {

}
