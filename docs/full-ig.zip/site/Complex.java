package http://www.fhir.org/guides/test4/ImplementationGuide/healthedatainc.ig-template4-0.0.0;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class Complex {

}
