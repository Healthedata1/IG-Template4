
{% assign id = {{page.id}} %}
source file: source/pages/\_includes/{{id}}-intro.md

{{site.data.structuredefinitions.[id].description}}

#### Scope and Usage

scope and usage text here

#### Mandatory Data Elements and Terminology

The following data-elements are mandatory (i.e data MUST be present). blah blah blah

**must have:**

1. blah
1. blah
1. blah

**Additional Profile specific implementation guidance:**

#### Examples

- list examples here

## NOTE if the status of the StructureDefinition is `draft` the rendering will only show the untabbed all view below.  To get the tabbed views of the resource change the status to `active`
