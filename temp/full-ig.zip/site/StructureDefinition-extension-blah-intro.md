
source: extension-blah.md file

    This is the introduction markdown file that gets inserted into the sd.html template.

    This profile sets minimum expectations for blah blah blah

    ##### Mandatory Data Elements and Terminology

    The following data-elements are mandatory (i.e data MUST be present). blah blah blah

    **must have:**

    1. blah
    1. blah
    1. blah

    **Additional Profile specific implementation guidance:**

    #### Examples
