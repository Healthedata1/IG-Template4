source: input/pagecontents/operationdefinition-example-notes.md file



    This is the  markdown file that gets inserted into the op.html template.
