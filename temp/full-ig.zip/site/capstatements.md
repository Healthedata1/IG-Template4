{% include list-capabilitystatements.xhtml %}
<br />
