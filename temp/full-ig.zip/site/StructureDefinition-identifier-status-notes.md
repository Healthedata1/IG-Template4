
{% assign id = {{page.id}} %}
source file: source/pages/\_includes/{{id}}-search.md

~~~
This is the search markdown file that gets inserted into the sd.html Quick Start section for explanation of the search requirements.
~~~
