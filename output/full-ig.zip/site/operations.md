
The following Operations have been defined for this implementation guide.

<!-- {%raw%}{% include list-operationdefinitions.xhtml %}{%endraw%}-->

{% include list-operationdefinitions.xhtml %}

<br />
